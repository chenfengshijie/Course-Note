实验二，两个项目都做了，所有函数的定义和实现都在lab.h lab.cpp中。



步骤：
1. 根据CMakeLists.txt生成程序（跨平台）
2. 运行生成的程序，能够得到experiments.txt文件，该文件保存了项目1所有实验数据，experiments_quicksort.txt保存了项目二的所有实验数据。
3. 运行plot.py 脚本，可以展现实验结果。
